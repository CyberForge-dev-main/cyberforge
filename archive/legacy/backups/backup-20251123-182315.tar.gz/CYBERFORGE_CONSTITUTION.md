# 🏛️ **CYBERFORGE PROJECT CONSTITUTION**

**ВЕРСИЯ 1.0 | Крайняя дата: 2025-11-23**

> Этот документ — ЕДИНЫЙ ИСТОЧНИК ИСТИНЫ для всех нейросетей, которые помогают разрабатывать CyberForge. Читай полностью перед началом работы.

---

## 📋 РАЗДЕЛ 1: ЧТО ТАКОЕ CYBERFORGE

### Определение (чёткое)

**CyberForge** — платформа для самохостируемой практики в кибербезопасности.

**Аналоги:** HackTheBox, TryHackMe, но:
- ✅ Можно запустить на своём сервере/ноуте (self-hosted)
- ✅ Полный контроль над данными
- ✅ Недорого (не нужна подписка)
- ✅ Масштабируемо (модульная архитектура)

### Не путать

🚫 Это НЕ учебный курс (хотя документация будет)  
🚫 Это НЕ MVP (уже полный рабочий продукт с бэком)  
🚫 Это НЕ облачный сервис (работает локально)

---

## 🏗️ РАЗДЕЛ 2: ТЕКУЩИЙ СТАТУС (Phase 2 - Stable)

### ✅ ЧТО РАБОТАЕТ

```
Docker Compose:
├─ Website (Nginx)         :3000 ✅
├─ SSH Challenge 1         :2222 ✅
├─ SSH Challenge 2         :2223 ✅
├─ SSH Challenge 3         :2224 ✅
├─ OWASP Juice Shop        :3001 ✅
└─ Backend API (Flask)     :5000 ✅

Функционал:
├─ User Auth (JWT)         ✅
├─ Challenge Management    ✅
├─ Flag Validation         ✅
├─ Leaderboard            ✅
├─ Progress Tracking      ✅
└─ API Documentation      ✅

Infrastructure:
├─ Git Repository         ✅
├─ Docker Setup          ✅
├─ Database (SQLite)     ✅
├─ Tests (Bash)          ✅
└─ Monitoring            ✅
```

### 🚀 ОСНОВНОЙ USERFLOW

```
1. Пользователь заходит на сайт (http://IP:3000)
2. Видит список челленджей (SSH, Web, etc)
3. Запускает челлендж
4. Подключается по SSH или открывает браузер
5. Решает задачу, находит флаг
6. Вводит флаг на сайте
7. Видит результат + очки на leaderboard
```

---

## 📁 РАЗДЕЛ 3: СТРУКТУРА ПРОЕКТА

### Иерархия файлов

```
~/Documents/cyberforge/
├─ backend/                    # Flask API
│  ├─ app.py                  # Главное приложение
│  ├─ config.py               # Конфигурация (SQLite!)
│  ├─ models.py               # Database models
│  ├─ auth.py                 # JWT authentication
│  ├─ requirements.txt         # Зависимости Python
│  ├─ Dockerfile              # Образ для бэка
│  └─ cyberforge.db           # SQLite БД (создаётся автоматически)
│
├─ src/                        # React Frontend
│  ├─ App.js                  # Главная компонента
│  ├─ api.js                  # HTTP клиент
│  ├─ components/
│  │  ├─ Dashboard.js         # Главная страница
│  │  ├─ Login.js             # Авторизация
│  │  └─ ChallengeList.js     # Список челленджей
│  ├─ index.js                # Entry point
│  └─ package.json            # React зависимости
│
├─ website/                    # Static HTML витрина
│  ├─ index.html              # Главная страница
│  └─ style.css               # Стили
│
├─ challenges/                 # SSH челленджи
│  ├─ ch1/
│  │  └─ Dockerfile           # Challenge 1 образ
│  ├─ ch2/
│  │  └─ Dockerfile           # Challenge 2 образ
│  └─ ch3/
│     └─ Dockerfile           # Challenge 3 образ
│
├─ tests/                      # Тестовые скрипты
│  ├─ test_api.sh             # API функциональные тесты
│  └─ test_ssh.sh             # SSH челленджи тесты
│
├─ scripts/                    # Утилиты
│  ├─ setup.sh                # Установка зависимостей
│  ├─ health_check.sh         # Проверка здоровья
│  └─ deploy.sh               # Быстрый деплой
│
├─ docker-compose.yml         # Оркестрация контейнеров
├─ .gitignore                 # Git ignore правила
├─ README.md                  # Документация
├─ ARCHITECTURE.md            # Техническая архитектура
└─ .github/
   └─ workflows/
      └─ tests.yml            # CI/CD (если настроено)
```

### ⚠️ КРИТИЧЕСКИ ВАЖНЫЕ ФАЙЛЫ

| Файл | Что может пойти не так | Как чинить |
|------|----------------------|-----------|
| `backend/config.py` | ДОЛЖНА быть `sqlite:///cyberforge.db`, НЕ postgresql | Проверь `SQLALCHEMY_DATABASE_URI` |
| `docker-compose.yml` | Пути на несуществующие `challenges/ch1-3` | Должны быть `challenges/ch1/Dockerfile` и т.д. |
| `backend/Dockerfile` | Может не скопировать зависимости | Проверь `COPY requirements.txt` строку |
| `challenges/ch*/Dockerfile` | SSH-ключи не созданы правильно | Проверь `useradd`, `ssh-keygen` команды |

---

## 🔧 РАЗДЕЛ 4: ЗАПУСК И ТЕСТИРОВАНИЕ

### Quick Start (всё работает)

```bash
cd ~/Documents/cyberforge

# 1. Убедиться что Docker запущен
docker --version

# 2. Собрать и запустить все контейнеры
docker compose up --build

# 3. Ждёшь, пока всё стартует (2-3 минуты)

# 4. Проверяешь:
curl http://localhost:3000          # Website
curl http://localhost:5000/api/health  # Backend
ssh -p 2222 ctfuser@localhost       # SSH Challenge 1
```

### Если что-то не работает

```bash
# 1. Посмотри логи
docker compose logs backend

# 2. Перестарт одного контейнера
docker compose restart backend

# 3. Полная пересборка (ядерная опция)
docker compose down -v
docker compose up --build
```

### Тестирование

```bash
# Автоматический тест API
cd ~/Documents/cyberforge/tests
bash test_api.sh

# Тест SSH челленджа
bash test_ssh.sh
```

---

## 🎯 РАЗДЕЛ 5: ПРАВИЛА ДЛЯ НЕЙРОСЕТЕЙ

### ✅ МОЖНО ДЕЛАТЬ

1. **Исправлять ошибки в коде** — если видишь баг, чини.
2. **Добавлять документацию** — комментарии, README-секции, примеры.
3. **Оптимизировать производительность** — если не ломается функционал.
4. **Проверять типы данных** — SQLite vs Postgres, ensure consistency.
5. **Писать тесты** — добавлять bash/python тесты.
6. **Улучшать UX** — фронт, логи, сообщения об ошибках.

### ❌ НИКОГДА НЕ ДЕЛАЙ

1. 🚫 **Не используй "MVP" как оправдание** — это полный продукт, не половинка.
2. 🚫 **Не меняй архитектуру без согласования** — обсуди с владельцем.
3. 🚫 **Не трогай SSH-челленджи структуру** — если работают, не чини.
4. 🚫 **Не добавляй PostgreSQL** — используем SQLite для простоты.
5. 🚫 **Не удаляй рабочий код** — всё переделаешь через рефакторинг.
6. 🚫 **Не игнорируй ошибки** — если что-то падает, стоп и разбирайся.

---

## 📊 РАЗДЕЛ 6: КОМПОНЕНТЫ И КАК ОНИ ВЗАИМОДЕЙСТВУЮТ

### Backend API (Flask)

**Файлы:** `backend/app.py`, `backend/models.py`, `backend/auth.py`

**Endpoints:**
```
POST   /api/register              # Регистрация
POST   /api/login                 # Вход
GET    /api/challenges            # Список челленджей
POST   /api/challenges/{id}/submit # Отправка флага
GET    /api/leaderboard           # Топ игроков
GET    /api/health                # Проверка здоровья
```

**Хранение данных:** SQLite (`cyberforge.db`)

**Аутентификация:** JWT tokens в куках

### Frontend (React)

**Файлы:** `src/App.js`, `src/components/*.js`

**Функции:**
- Login / Register
- Dashboard (список челленджей)
- Challenge viewer (инструкции)
- Flag submit form
- Leaderboard

**Коммуникация:** HTTP запросы к backend API

### SSH Челленджи

**Структура:**
```
challenges/ch1/Dockerfile  → Образ контейнера
ssh -p 2222 ctfuser@localhost → Подключение
```

**Флаги:**
- Ch1: `flag{welcome_to_cyberforge_1}`
- Ch2: `flag{linux_basics_are_fun}`
- Ch3: `flag{find_and_conquer}`

**Как работает:**
1. Docker создаёт контейнер с Linux
2. Внутри спрятана задача и флаг
3. Юзер решает задачу, находит флаг
4. Вводит флаг на сайте
5. Backend проверяет через БД

---

## 🔐 РАЗДЕЛ 7: БАЗА ДАННЫХ

### Схема (SQLite)

```sql
-- Пользователи
CREATE TABLE users (
    id INTEGER PRIMARY KEY,
    username VARCHAR(255) UNIQUE,
    email VARCHAR(255) UNIQUE,
    password_hash VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Челленджи
CREATE TABLE challenges (
    id INTEGER PRIMARY KEY,
    name VARCHAR(255),
    description TEXT,
    flag VARCHAR(255),
    points INTEGER,
    port INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Прогресс пользователя
CREATE TABLE user_progress (
    id INTEGER PRIMARY KEY,
    user_id INTEGER FOREIGN KEY,
    challenge_id INTEGER FOREIGN KEY,
    solved BOOLEAN DEFAULT FALSE,
    points_earned INTEGER,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Отправленные флаги
CREATE TABLE flag_submissions (
    id INTEGER PRIMARY KEY,
    user_id INTEGER FOREIGN KEY,
    challenge_id INTEGER FOREIGN KEY,
    submitted_flag VARCHAR(255),
    correct BOOLEAN,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Как проверяется флаг

```
1. Юзер отправляет флаг через фронт
2. Backend получает POST запрос
3. Backend ищет флаг в challenges таблице
4. Сравнивает: submitted_flag == correct_flag
5. Если правильно → записывает в flag_submissions (correct=true)
6. Обновляет user_progress (solved=true, points+=100)
7. Возвращает результат фронту
```

---

## 🐛 РАЗДЕЛ 8: ТИПИЧНЫЕ ПРОБЛЕМЫ И РЕШЕНИЯ

### Проблема 1: Backend не запускается (Connection refused на 5000)

**Диагностика:**
```bash
docker compose logs backend
```

**Решение:**
1. Проверь `config.py` — должна быть `sqlite:///cyberforge.db`
2. Если там postgres — поменяй на sqlite
3. Перестарт контейнера: `docker compose restart backend`

### Проблема 2: SSH челленджи не видны

**Диагностика:**
```bash
docker compose ps | grep challenge
```

**Решение:**
1. Проверь папки: `ls challenges/ch{1,2,3}/Dockerfile`
2. Если не существуют → создай: `mkdir -p challenges/ch{1,2,3}`
3. Переместить Dockerfiles: `mv Dockerfile.chX challenges/chX/Dockerfile`
4. Пересобрать: `docker compose up --build`

### Проблема 3: Frontend не подключается к backend

**Диагностика:**
```bash
curl http://localhost:5000/api/health
```

**Решение:**
1. Убедись что backend работает (лог выше)
2. Проверь CORS в `backend/app.py` — должен быть `CORS(app)`
3. Проверь API URL в `src/api.js` — должен быть `http://localhost:5000`

### Проблема 4: БД закешировалась (старые данные)

**Решение:**
```bash
docker compose down -v     # Удали volumes
docker compose up --build  # Пересоздай всё
```

---

## 📈 РАЗДЕЛ 9: ROADMAP (ФИ НА БУДУЩЕЕ)

### ✅ Завершено (Phase 1-2)

- [x] SSH челленджи 
- [x] Backend API
- [x] Frontend Dashboard
- [x] Database (SQLite)
- [x] Authentication (JWT)
- [x] Leaderboard

### 🚧 В процессе (Phase 3)

- [ ] Web-лабы (OWASP Juice Shop интеграция)
- [ ] CI/CD (GitHub Actions)
- [ ] Documentation (Swagger/OpenAPI)

### 📋 Планируется (Phase 4+)

- [ ] Kubernetes deployment
- [ ] Multi-server setup
- [ ] Custom challenge builder
- [ ] API для создания своих челленджей

---

## 📞 РАЗДЕЛ 10: КОНТАКТЫ И ПОДДЕРЖКА

### GitHub

- **Репозиторий:** https://github.com/CyberForge-dev-main/cyberforge
- **Issues:** Создавай issue для багов
- **Branches:** `main` (production), `dev` (development)

### Как коммитить

```bash
git add .
git commit -m "Phase X: [Что сделал] [Краткое описание]"
git push origin main
```

### Вопросы для нейросетей

**ДО начала работы:** Прочитай этот документ полностью.

**ЕСЛИ путаешься:** Обращайся к разделам выше.

**ЕСЛИ видишь ошибку:** Описывай точно, какой файл, какая строка.

---

## 🎓 РАЗДЕЛ 11: ДЛЯ ДРУГИХ НЕЙРОСЕТЕЙ

### Как читать эту конституцию

1. **Сначала Раздел 1-2** — понимаешь что это
2. **Потом Раздел 3** — видишь структуру проекта
3. **Раздел 5** — запомниваешь что можно/нельзя делать
4. **Раздел 6** — разбираешься как всё связано
5. **Раздел 8** — если что-то сломано, ищешь здесь решение

### Когда игнорировать эту конституцию

Никогда. Не игнорируй.

---

## 📝 ИСТОРИЯ ВЕРСИЙ

| Версия | Дата | Изменения |
|--------|------|-----------|
| 1.0 | 2025-11-23 | Первая версия. Объединена информация из 3 документов истории разработки. |

---

**СОЗДАНО:** 2025-11-23  
**ПОСЛЕДНЕЕ ОБНОВЛЕНИЕ:** 2025-11-23  
**АВТОР:** AI Assistant (Perplexity)  
**КОНТЕКСТ:** CyberForge Project Documentation

> **"Не идеалов ищи, ищи правды. Правда тебя спасет."** ©