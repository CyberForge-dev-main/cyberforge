#!/bin/bash

# Скрипт для безопасного коммита в CyberForge

if [ -z "$1" ]; then
    echo "Использование: bash scripts/commit.sh \"сообщение коммита\""
    echo "Пример: bash scripts/commit.sh \"Add Backend Flask app\""
    exit 1
fi

COMMIT_MSG="$1"

echo "📝 Коммит: $COMMIT_MSG"
echo ""

# Шаг 1: Проверка статуса
echo "▶ Проверка Git статуса..."
if ! git status > /dev/null 2>&1; then
    echo "✗ Ошибка Git"
    exit 1
fi

# Шаг 2: Показать что будет коммичено
echo "▶ Изменения:"
git status --short | sed 's/^/  /'
echo ""

# Шаг 3: Запрос подтверждения
read -p "Продолжить коммит? (y/n): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Отменено"
    exit 0
fi

# Шаг 4: Добавить все файлы
echo "▶ Добавляю файлы..."
git add -A

# Шаг 5: Коммит (pre-commit hook запустится автоматически)
echo "▶ Коммит..."
git commit -m "$COMMIT_MSG"

if [ $? -eq 0 ]; then
    echo ""
    echo "✓ Коммит успешен!"
    echo ""
    echo "▶ Загрузка на GitHub..."
    git push origin main
    
    if [ $? -eq 0 ]; then
        echo "✓ Загружено на GitHub!"
    else
        echo "⚠ Загрузка не удалась (можно повторить позже)"
    fi
else
    echo "✗ Ошибка при коммите (проверьте pre-commit hook)"
    exit 1
fi
